module smExample1 {
	requires java.desktop;
}